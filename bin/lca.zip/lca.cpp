void inizia(int N, int T, int A[], int B[], int C[]) {
	return ;
}

long long int distanza1(int u, int v) {
	return 123456789123ll;
}

long long int distanza2(int u, int v) {
	return 123456789123ll;
}

long long int minimo(int u, int v) {
	return 123456789123ll;
}

long long int massimo(int u, int v) {
	return 123456789123ll;
}

